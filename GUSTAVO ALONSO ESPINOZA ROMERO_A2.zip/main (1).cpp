/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    float x,y,suma,resta,multiplicacion,division;
    
    cout<<"ingresar primer numero entero o decimal ";cin>>x;
    cout<<"ingresar segundo numero entero o decimal";cin>>y;
    
    suma=x+y;
    resta=x-y;
    multiplicacion=x*y;
    division=x/y;
    
    cout<<"la suma es:"<<x<<"+"<<y<<"="<<suma<<endl;
    cout<<"la resta es:"<<x<<"-"<<y<<"="<<resta<<endl;
    cout<<"la multiplicacion es:"<<x<<"*"<<y<<"="<<multiplicacion<<endl;
    cout<<"la division es:"<<x<<"/"<<y<<"="<<division<<endl;
    
    
    
    
    
    
    
    return 0;
}